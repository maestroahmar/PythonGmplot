import math
import requests
import json
import os
import webbrowser

from color_dicts import mpl_color_map, html_color_codes



class GoogleMapPlotter(object):

	def __init__(self, center_lat, center_lng, zoom):
		try:
			self.center = (float(center_lat), float(center_lng))
		except ValueError:
			print ("PLease correct the co ordinates")


		self.zoom = int(zoom)
		self.grids = None
		self.paths = []
		self.shapes = []
		self.points = []
		self.heatmap_points = []
		self.radpoints = []
		self.gridsetting = None
		self.coloricon = os.path.join(os.path.dirname(__file__), 'markers/%s.png')
		self.color_dict = mpl_color_map
		self.html_color_codes = html_color_codes

	@classmethod
	def from_geocode(cls, location_string, zoom=13):
		lat, lng = cls.geocode(location_string)
		return cls(lat, lng, zoom)

	@classmethod
	def geocode(self, location_string):
		geocode = requests.get(
			'http://maps.googleapis.com/maps/api/geocode/json?address="%s"' % location_string)
		
		geocode = json.loads(geocode.text)
		latlng_dict = geocode['results'][0]['geometry']['location']
		return latlng_dict['lat'], latlng_dict['lng']


	def marker(self, lat, lng, color='#FF0000', c=None):
		if c:
			color = c
		color = self.color_dict.get(color, color)
		color = self.html_color_codes.get(color, color)
		self.points.append((lat, lng, color[1:]))
	   


	
  
	# create the html file which include one google map and all points and
	# paths
	def draw(self, htmlfile,mymap):
		f = open(htmlfile, 'w')
		f.write('<html>\n')
		f.write('<head>\n')
		f.write(
			'<meta name="viewport" content="initial-scale=1.0, user-scalable=no" />\n')
		f.write(
			'<meta http-equiv="content-type" content="text/html; charset=UTF-8"/>\n')
		f.write('<title>Google Maps - pygmaps </title>\n')
		f.write('<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?libraries=visualization&sensor=true_or_false"></script>\n')
		f.write('<script type="text/javascript">\n')
		f.write('\tfunction initialize() {\n')
		self.write_map(f)
		read_file = open("Locations.txt","r")
		places = []
		text = read_file.readline()
		while text != "":
			places.append(text)
			text = read_file.readline()
		for i in places:
			
			lati,lang = mymap.geocode(i)
			#lat, lng = GoogleMapPlotter.geocode(i)
		
			mymap.marker(lati, lang, "red")
			
			self.write_points(f)
		

	   
		f.write('\t}\n')
		f.write('</script>\n')
		f.write('</head>\n')
		f.write(
			'<body style="margin:0px; padding:0px;" onload="initialize()">\n')
		f.write(
			'\t<div id="map_canvas" style="width: 100%; height: 100%;"></div>\n')
		f.write('</body>\n')
		f.write('</html>\n')
		f.close()
		webbrowser.open_new("geolocation.html")
		
	 

	#############################################
	# # # # # # Low level Map Drawing # # # # # #
	#############################################

	

	def write_points(self, f,):
		for p in self.points:
			print "Each point prints"
			print p
		for point in self.points:
			self.write_point(f, point[0], point[1], point[2])




	# TODO: Add support for mapTypeId: google.maps.MapTypeId.SATELLITE
	def write_map(self,  f):
		f.write('\t\tvar centerlatlng = new google.maps.LatLng(%f, %f);\n' %
				(self.center[0], self.center[1]))
		f.write('\t\tvar myOptions = {\n')
		f.write('\t\t\tzoom: %d,\n' % (self.zoom))
		f.write('\t\t\tcenter: centerlatlng,\n')
		f.write('\t\t\tmapTypeId: google.maps.MapTypeId.ROADMAP\n')
		f.write('\t\t};\n')
		f.write(
			'\t\tvar map = new google.maps.Map(document.getElementById("map_canvas"), myOptions);\n')
		f.write('\n')

	def write_point(self, f, lat, lon, color):
		print("\n")
		print "Entering write_point for %f and %f" %(lat,lon)
		f.write('\t\tvar latlng = new google.maps.LatLng(%f, %f);\n' %
				(lat, lon))
		f.write('\t\tvar img = new google.maps.MarkerImage(\'%s\');\n' %
				(self.coloricon % color))
		f.write('\t\tvar marker = new google.maps.Marker({\n')
		f.write('\t\ttitle: "",\n')
		f.write('\t\ticon: img,\n')
		f.write('\t\tposition: latlng\n')
		f.write('\t\t});\n')
		f.write('\t\tmarker.setMap(map);\n')
		f.write('\n')
		print("\n")

   

if __name__ == "__main__":


	
	l1, l2 = GoogleMapPlotter.geocode("New York")
	mymap = GoogleMapPlotter(l1,l2,4)
	mymap.draw('./geolocation.html',mymap)


