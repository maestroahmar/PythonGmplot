
<!DOCTYPE HTML>
<html>
<head>
<title>Foodlacious - About Me</title>
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href='http://fonts.googleapis.com/css?family=Merriweather+Sans' rel='stylesheet' type='text/css'>
</head>
<body>
<div class="header-box"></div>
<div class="wrap"> 
	<div class="total">
		<div class="header">
			<div class="header-bot">
				<div class="logo">
					<a href="index.html"><img src="images/restaurant logo.png" alt=""/></a>
				</div>
				<ul class="follow_icon">
					<li><a href="#"><img src="images/fb1.png" alt=""></a></li>
					<li><a href="#"><img src="images/rss.png" alt=""></a></li>
					<li><a href="#"><img src="images/tw.png" alt=""></a></li>
					<li><a href="#"><img src="images/g+.png" alt=""></a></li>
				</ul>
			    <div class="clear"></div> 
			</div>
			<div class="search-bar">
			    <input type="text" class="textbox" value=" Search" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Search';}">
			    <input name="searchsubmit" type="image" src="images/search-icon.png" value="Go" id="searchsubmit" class="btn">
         	     <div class="clear"></div>
    		</div>
			<div class="clear"></div> 
		 </div>	
		<div class="menu"> 	
			<div class="top-nav">
				<ul>
					<li><a href="index.php">Home</a></li>
					<li class="active"><a href="">About</a></li> 
					<li><a href="menu.php">Menu</a></li> 
					<li><a href="services.html">Services</a></li> 
					<li><a href="contact.php">Contact</a></li>
				</ul>
			</div>
		</div>		
		<div class="banner">
		</div>
   </div>
<div class="main">
	  <div class="section group">
				<div class="lsidebar1 span_1_of_a offers_list">
				      <h3></h3>
				     	<div class="testimonials">
		  					 <h3><span><a href="#">.</a></span></h3>
                                                         <p><span class="quotes"></span><h1>.......Our Products are blissfully created by our world class chefs using finest ingredients for the connoisseur.</h1><span class="quotes-down"></span></p>
		  				</div>
		  				<div class="testimonials">
		  					 <h3>.<span><a href="#">.</a></span></h3>
                                                         <p><span class="quotes"></span><h1>.......There is one inexhaustible aspect of everyday life that never dulls namely the simple pleasure of eating and drinking.</h1><span class="quotes-down"></span></p>
		  				</div>
						</div>
					 <div class="cont1 span_2_of_a about_desc">
				       <h3>About Us</h3>
		    			   <p><span>We are a multi-cuisine restaurant specializing in a variety of Indian,Mughlai,Chinese and Continental dishes that instantly become a favourite of all those who try them out at our fabulous restaurant with delightful interiors. These dishes are prepared in our kitchens with all the ingredients carefully sourced from sustainable sources. Everything is prepared freshly by us so that you get the original taste which you will want to experience again and again.</span></p>
				           <p>We host a wide range of events and parties so that we can make a place in people's hearts and also so that we can create memories that can be cherished for years to come. Be it Marriage parties, Birthday bashes or year-end celebrations, we cater to the needs of all such events and also organize our own functions which are truly a memorable event for the entire city.</p>
					        <div class="image group">
							   <div class="grid images_3_of_1">
								<img src="images/swat-2.jpg" alt=""/>
								</div>
									<div class="grid span_2_of_1">
                                                                            <u><h4>A refreshing difference... we assure.</h4></u>
											<p>Here we take Indian-inspired food to a whole new level with our healthy cooking approach and techniques. We have adopted some techniques from the old philosophies and believe that cooking Indian food must be done slowly and deliberately. We have analyzed our cooking times and processes to ensure he proper preparation and cooking times, the same way you would cook for yourself at home . Our food is always made from scratch with no preservatives and artificial flavours. With our natural ingredients and fresh- milled spices, you can enjoy a guilt-free meal that is quick,easy, affordable and delicious. </p>
									          <div class="more">
								         	  	<a href="#" class="button">Read More</a>
								         </div>
							   		</div>
			  				 </div>
				      </div>	
				      <div class="clear"></div> 			
		   		</div>
		   		<div class="heading">
				  	<h3>Our Staff</h3>
				</div>
		   		<div class="about-bottom">
				<div class="col_1_of_4 span_1_of_4">
					<img src="images/pic17.jpg" alt=""/>
						<div class="item_content">
 							<h6 class="item_title">
							<span class="item_title_part0">Ahmar Abdullah </span></h6>
							<div class="item_text"><p>lorem ipsum doloerut</p></div>
							<div class="item_text"><p>Ph No:800-000000</p></div>
							<span class="item_title_part0">ahmarzaf@iul.ac.in</span>
						</div>
				</div>
				<div class="col_1_of_4 span_1_of_4">
					<img src="images/pic18.jpg" alt=""/>
						<div class="item_content">
 							<h6 class="item_title">
							<span class="item_title_part0">Anam Najeeb </span></h6>
							<div class="item_text"><p>lorem ipsum doloerut</p></div>
							<div class="item_text"><p>Ph No:800-000000</p></div>
							<span class="item_title_part0">anamnaje@iul.ac.in </span>
						</div>
				</div>
				<div class="col_1_of_4 span_1_of_4">
					<img src="images/pic19.jpg" alt=""/>
						<div class="item_content">
 							<h6 class="item_title">
							<span class="item_title_part0">Arisha Zaidi</span></h6>
							<div class="item_text"><p>lorem ipsum doloerut</p></div>
							<div class="item_text"><p>Ph No:800-000000</p></div>
							<span class="item_title_part0">arishaza@iu.ac.in</span>
						</div>
				</div>
				<div class="col_1_of_4 span_1_of_4">
					<img src="images/pic20.jpg" alt=""/>
						<div class="item_content">
 							<h6 class="item_title">
							<span class="item_title_part0">Aleesha Zaidi</span></h6>
							<div class="item_text"><p>lorem ipsum doloerut</p></div>
							<div class="item_text"><p>Ph No:800-000000</p></div>
							<span class="item_title_part0">aleeshazaidi@iul.ac.in</span>
						</div>
				</div>
				<div class="clear"></div> 		
			</div>
		     <div class="clear"> </div>
			</div>
	</div>
<div class="footer-bottom">
 	<div class="wrap">
 		<div class="copy">
			<p> © 2016 All rights Reserved | Design by <a href="http://w3layouts.com">FOODLACIOUS</a></p>
		</div>
 	</div>
 </div>
</body>
</html>

    	
    	
            