
<!DOCTYPE HTML>
<html>
<head>
<title>My Restaurant website</title>
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href='http://fonts.googleapis.com/css?family=Merriweather+Sans' rel='stylesheet' type='text/css'>
</head>
<body>
<div class="header-box"></div>
<div class="wrap"> 
	<div class="total">
		<div class="header">
			<div class="header-bot">
				<div class="logo">
					<a href="index.html"><img src="images/restaurant logo.png" alt=""/></a>
				</div>
				<ul class="follow_icon">
					<li><a href="#"><img src="images/fb1.png" alt=""></a></li>
					<li><a href="#"><img src="images/rss.png" alt=""></a></li>
					<li><a href="#"><img src="images/tw.png" alt=""></a></li>
					<li><a href="#"><img src="images/g+.png" alt=""></a></li>
				</ul>
			    <div class="clear"></div> 
			</div>
			<div class="search-bar">
			    <input type="text" class="textbox" value=" Search" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Search';}">
			    <input name="searchsubmit" type="image" src="images/search-icon.png" value="Go" id="searchsubmit" class="btn">
         	     <div class="clear"></div>
    		</div>
			<div class="clear"></div> 
		 </div>	
		<div class="menu"> 	
			<div class="top-nav">
				<ul>
                                    <li><a href="index.php">Home</a></li>
                                    <li><a href="about.php">About</a></li> |
                                    <li><a href="menu.php">Menu</a></li> |
					<li class="active"><a href="l">Services</a></li> |
					<li><a href="contact.php">Contact</a></li>
				</ul>
			</div>
		</div>		
		<div class="banner">
		</div>
   </div>
<div class="main">
	  <div class="section group">
					 <div class="cont2 span_2_of_services services_desc">
				       <h2>Our Services</h2>
                                       <p><h1><u>READY-TO-EAT MEALS</u></h1></p>
				           <p>Our ready-to-eat range of fresh, healthy and delicious Indian,Italian,Continental and Barbeque cuisines make the perfect meal for our customers      .</p>
					        <div class="image group">
							   <div class="grid images_3_of_1">
								<img src="images/bg01.jpg" alt=""/>
								</div>
									<div class="grid span_2_of_1">
                                                                            <h1><u>FUNCTION CATERING</u></h1>
											<p>Our delicious and healthy platters are a great alternative to traditional finger food. We specialise in high volume, event style corporate catering, including corporate boxes at sporting evens and other large company functions.If you are looking for something new and different for your next event, why not try of our all-in-one meal packs. We can coordinate and plan a menu to suit your event.</p>
							   		</div>
							   		<div class="clear"></div> 
			  				 </div>
			  				 <div class="image group">
							   <div class="grid images_3_of_1">
								<img src="images/IMG_2656.jpg" alt="">
								</div>
									<div class="grid span_2_of_1">
										<h1><u>DELIVERY SERVICE</u></h1>
											<p>Our Foodelicious fleet of refrigerated vans transports all orders fresh daily across the Lucknow area-365 days a year. We work to your event timeframes to meet your event deadlines.</p>						         	  	
							   		</div>
							   		<div class="clear"></div> 
			  				 </div>
			  				 <div class="read_more" style="text-align:right"><a href="#">View All</a></div>
				      </div>
				      <div class="lsidebar2 sidebar2 offers_list">
				         <h2>What We Offer</h2>
				     		<ul>
		  						<li>Delicious Indian,Italian,Chinese,Continental cuisines</li>
		  						<li>Ready-to-eat meals</li>
		  						<li>Function Catering</li>
		  						<li>Delivery Service</li>
		  						<li>Airline Catering</li>
		  						<li>Birthdays and special occasions</li>
		  						<li>Music events</li>
		  						
		  					</ul>
		  				<div class="archives">
		  					<h2>Achivements</h2>
		  					 <ul>
		  						<li>March 2015</li>
		  						<li>June 2013</li>
		  						<li>May 2012</li>
		  						<li>January 2010</li>
		  					  </ul>
						</div>				
		   		</div> 
		   		<div class="clear"></div> 		
	          </div>
		   		<div class="heading">
				  	<h3>Our Staff</h3>
				</div>
		   		<div class="about-bottom">
				<div class="col_1_of_4 span_1_of_4">
					<img src="images/pic17.jpg" alt=""/>
						<div class="item_content">
 							<h6 class="item_title">
							<span class="item_title_part0">Ahmar Abdullah</span></h6>
							<div class="item_text"><p>lorem ipsum doloerut</p></div>
							<div class="item_text"><p>Ph No:800-000000</p></div>
							<span class="item_title_part0">ahmarzaf@iul.ac.in</span>
						</div>
				</div>
				<div class="col_1_of_4 span_1_of_4">
					<img src="images/pic18.jpg" alt=""/>
						<div class="item_content">
 							<h6 class="item_title">
							<span class="item_title_part0">Anam Najeeb</span></h6>
							<div class="item_text"><p>lorem ipsum doloerut</p></div>
							<div class="item_text"><p>Ph No:800-000000</p></div>
							<span class="item_title_part0">anamnaje@iul.ac.in</span>
						</div>
				</div>
				<div class="col_1_of_4 span_1_of_4">
					<img src="images/pic19.jpg" alt=""/>
						<div class="item_content">
 							<h6 class="item_title">
							<span class="item_title_part0">Arisha Zaidi</span></h6>
							<div class="item_text"><p>lorem ipsum doloerut</p></div>
							<div class="item_text"><p>Ph No:800-000000</p></div>
							<span class="item_title_part0">arishaza@iul.ac.in</span>
						</div>
				</div>
				<div class="col_1_of_4 span_1_of_4">
					<img src="images/pic20.jpg" alt=""/>
						<div class="item_content">
 							<h6 class="item_title">
							<span class="item_title_part0">Aleesha Zaidi</span></h6>
							<div class="item_text"><p>lorem ipsum doloerut</p></div>
							<div class="item_text"><p>Ph No:800-000000</p></div>
							<span class="item_title_part0">aleeshazaidi@iu.ac.in </span>
						</div>
				</div>
				<div class="clear"></div> 		
			</div>
		     <div class="clear"> </div>
			</div>
	</div>
<div class="footer-bottom">
 	<div class="wrap">
 		<div class="copy">
			<p> © 2016 All rights Reserved | Design by <a href="http://w3layouts.com">FOODLACIOUS</a></p>
		</div>
 	</div>
 </div>
</body>
</html>

    	
    	
            