
<!DOCTYPE HTML>
<html>
<head>
<title>FoodLacious</title>
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<script type="text/javascript" src="js/jquery-1.11.0.min.js"></script>
<script type="text/javascript" src="js/jquery.leanModal.min.js"></script>
<link rel="stylesheet" href="http://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.min.css" />
<link type="text/css" rel="stylesheet" href="css/style.css" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="google-signin-scope" content="profile email">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="http://code.jquery.com/mobile/1.4.5/jquery.mobile-1.4.5.min.css">
<script src="http://code.jquery.com/jquery-1.11.3.min.js"></script>
<script src="http://code.jquery.com/mobile/1.4.5/jquery.mobile-1.4.5.min.js"></script>
    <meta name="google-signin-client_id" content="67247211250-1390p0tcv7du35pjk5jthnk2mnhvdn79.apps.googleusercontent.com">
    <script src="https://apis.google.com/js/platform.js" async defer></script>
<link href='http://fonts.googleapis.com/css?family=Merriweather+Sans' rel='stylesheet' type='text/css'>
<!--slider-->
<link rel="stylesheet" href="css/flexslider.css" type="text/css" media="all" />
<script src="js/modernizr.js"></script>
<!-- jQuery -->
 <script src="js/jquery.min.js"></script>
  <script>window.jQuery || document.write('<script src="js/libs/jquery-1.7.min.js">\x3C/script>')</script>
  <!-- FlexSlider -->
  <script defer src="js/jquery.flexslider.js"></script>
  <script type="text/javascript">
    $(function(){
      SyntaxHighlighter.all();
    });
    $(window).load(function(){
      $('.flexslider').flexslider({
        animation: "slide",
        start: function(slider){
          $('body').removeClass('loading');
        }
      });
    });
  </script>
</head>
<body >
    
    
<div class="header-box"></div>
<div class="wrap"> 
	<div class="total">
		<div class="header">
			<div class="header-bot">
				<div class="logo">
					<a href="index.html"><img src="images/restaurant logo.png" alt=""/></a>
				</div>
				<ul class="follow_icon">
					<li><a href="#"><img src="images/fb1.png" alt=""></a></li>
					<li><a href="#"><img src="images/rss.png" alt=""></a></li>
					<li><a href="#"><img src="images/tw.png" alt=""></a></li>
					<li><a href="#"><img src="images/g+.png" alt=""></a></li>
                                        <li><div class="g-signin2" data-onsuccess="onSignIn" data-theme="dark"></div>
    <script>
      function onSignIn(googleUser) {
        // Useful data for your client-side scripts:
        var profile = googleUser.getBasicProfile();
        console.log("ID: " + profile.getId());
        // Don't send this directly to your server!
        console.log('Full Name: ' + profile.getName());
         name = profile.getName();
         
         document.getElementById("dispname").innerHTML = name;
         document.getElementById("fname").innerHTML = name;
        
        console.log('Given Name: ' + profile.getGivenName());
         pname = profile.getGivenName();
        console.log('Family Name: ' + profile.getFamilyName());
                 fname = profile.getFamilyName();
        console.log("Image URL: " + profile.getImageUrl());
         img = profile.getImageUrl();
         document.getElementById("prof").innerHTML = img;
         document["prof"].src = img.src;
        console.log("Email: " + profile.getEmail());
         mail = profile.getEmail();
                  document.getElementById("email").innerHTML = mail;
                  var ename = document.createElement("input");
                  ename.setAttribute("id",name);
                  ename.setAttribute("type","text");
                  
                  
                  

         
        
      

        // The ID token you need to pass to your backend:
        var id_token = googleUser.getAuthResponse().id_token;
        console.log("ID Token: " + id_token);
      };
      
      
      
    </script>
    
    
   
                                        </li>
                                        <li>
                                            <div id="fb-root" ></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/sdk.js#xfbml=1&version=v2.5&appId=1671189163146126";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<div class="fb-login-button" data-max-rows="1" data-size="large" data-show-faces="false" data-auto-logout-link="false"></div>
                                        </li>
                                        
				</ul>
                            
                            
    
			</div>
                    
 

  <div data-role="main" class="ui-content">

    <div data-role="popup" id="myPopup" class="ui-content" style="min-width:250px;">
        <?php
	$rss = new DOMDocument();
        
	$rss->load('http://rss.tasteofhome.com/feed-recipe-of-the-day.rss');
	$feed = array();
	foreach ($rss->getElementsByTagName('item') as $node) {
		$item = array ( 
			'title' => $node->getElementsByTagName('title')->item(0)->nodeValue,
			'desc' => $node->getElementsByTagName('description')->item(0)->nodeValue,
			'link' => $node->getElementsByTagName('link')->item(0)->nodeValue,
			'date' => $node->getElementsByTagName('pubDate')->item(0)->nodeValue,
			);
		array_push($feed, $item);
	}
	$limit = 1;
	for($x=0;$x<$limit;$x++) {
		$title = str_replace(' & ', ' &amp; ', $feed[$x]['title']);
		$link = $feed[$x]['link'];
		$description = $feed[$x]['desc'];
		$date = date('l F d, Y', strtotime($feed[$x]['date']));
		echo '<p><strong><a href="'.$link.'" title="'.$title.'">'.$title.'</a></strong><br />';
		echo '<small><em>Posted on '.$date.'</em></small></p>';
		echo '<p>'.$description.'</p>';
	}
?>
        
      
        
             
          
       
        
    </div>
  </div>
                    
			<div class="search-bar">
                            <form action="orderonline.php" method="post">
                            <button id="dispname" title="Visitor">VISITOR</button>
                            <input type="hidden" id="name" value="name">
                            <input type="hidden" id="mail" value="mail">
                            
                            </form>
    		</div>
      
      
			<div class="clear"></div> 
		 </div>	
		<div class="menu"> 	
			<div class="top-nav">
				<ul>
					<li class="active"><a href="">Home</a></li>
                                        <li><a href="about.php">About</a></li> |
                                        <li><a href="menu.php">Menu</a></li> |
                                        <li><a href="services.php">Services</a></li> |
                                        <li><a href="contact.php">Contact</a></li>
                                        <li>    <a href="#myPopup" data-rel="popup">Recipe of the Day</a> </li>
                                        <li><a href="menu.php">Order Online</a></li>
                                            
                                     
                                            
                                        
                                            
</li>
                                        
				</ul>
			</div>
		</div>		
		<div class="banner">
			<div class="flexslider">
	          <ul class="slides">
                

	            
	  	    	<li><img src="images/bg01.jpg"  alt=""/></li>
	  	    	<li><img src="images/full-hd-wallpaper-food-65.jpg"  alt=""/></li>
                      <li><img src="images/south_indian1.jpg"  alt=""/></li>
                      
                      <li><img src="images/swat-1.jpg"  alt=""/></li>
                      <li><img src="images/pizza.jpg"  alt=""/></li>
                      <li><img src="images/swat-2.jpg"  alt=""/></li>
                      <li><img src="images/IMG_2656.jpg"  alt=""/></li>
	        </div>
	   </div>
   </div>
           
<div class="main">
	   <div class="heading3">
		    <h3>Today's Special</h3>
	    </div>
	    <div class="section group">
                <marquee behavior =" scroll" direction ="left">
				<div class="col_1_of_4 span_1_of_4">
					<img src="images/pic.jpg" alt=""/>
					<div class="desc">
						<div class="left-text">
							<h5>
						<a href="#">Tangrine Chicken</a></h5>
						</div>
						<span class="price"><small>&#x20B9</small> 500</span>
					</div>
				  </div>
			    <div class="col_1_of_4 span_1_of_4">
					<img src="images/pic1.jpg" alt=""/>
					<div class="desc">
						<div class="left-text">
							<h5>
						<a href="#">Pappariza</a></h5>
						</div>
						<span class="price"><small>&#x20B9</small>600</span>
					</div>
				  </div>
				<div class="col_1_of_4 span_1_of_4">
					<img src="images/pic2.jpg" alt=""/>
					<div class="desc">
						<div class="left-text">
							<h5>
						<a href="#">Italian Salad</a></h5>
						</div>
						<span class="price"><small>&#x20B9</small>400</span>
					</div>
				  </div>
				<div class="col_1_of_4 span_1_of_4 active-grid">
					<img src="images/pic3.jpg" alt=""/>
					<div class="last-desc">
						<div class="left-text">
							<h6>
						<a href="#">Spanish Wine</a></h6>
						</div>
						<span class="price-last"><small>&#x20B9</small>1100</span>
					</div>
				</div>
				<div class="clear"></div>  </marquee>
			</div>
		   <div class="content-middle">
				<div class="lsidebar span_1_of_3">
					<div class="widget_wrap" style="width:350px;height:400px;"><iframe src="https://www.zomato.com/widgets/res_search_widget.php?city_id=8&language_id=1&theme=red&widgetType=custom&sort=popularity" style="position:relative;width:100%;height:100%;" border="0" frameborder="0"></iframe></div>
				</div>
				<div class="cont span_2_of_3">
                                    <div> <div>
<div class="widget_wrap" style="width:800px;height:400px;"><iframe src="https://www.zomato.com/widgets/o2.php?loc_name=Lucknow&lat=26.8467&lon=80.9462&theme=red&widgetType=custom&sort=rating" style="position:relative;width:100%;height:100%;" border="0" frameborder="0"></iframe></div>			    </div>	
                                    </div> </div>
                        		<div class="clear"></div> 		
		   </div>
		   <div class="bottom-grids">
				  <div class="bottom-grid1">
							<h3>WHAT EXPERTS SAY</h3>
                                                        <a class="twitter-timeline" href="https://twitter.com/NDTVFood" data-widget-id="719508397226397696">Food Channel says @NDTVFood</a>
<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+"://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>

<a class="twitter-timeline" href="https://twitter.com/SanjeevKapoor" data-widget-id="719511265455042560">Top Chef says @SanjeevKapoor</a>
<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+"://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>

									
								</div>
								<div class="bottom-grid2 bottom-mid">
									<h3>Updated Menu</h3>
									<div class="gallery">
										<ul>
                                                                                    <marquee behavior =" scroll" direction ="up">
												<li><a href="images/t-pic5.jpg"><img src="images/pic5.jpg" alt=""></a></li>
												<li><a href="images/t-pic6.jpg"><img src="images/pic6.jpg" alt=""></a></li>
												<li><a href="images/t-pic7.jpg"><img src="images/pic7.jpg" alt=""></a></li>
												<li><a href="images/t-pic8.jpg"><img src="images/pic8.jpg" alt=""></a></li>
												<li><a href="images/t-pic9.jpg"><img src="images/pic9.jpg" alt=""></a></li>
												<li><a href="images/t-pic10.jpg"><img src="images/pic10.jpg" alt=""></a></li>
												<li><a href="images/t-pic11.jpg"><img src="images/pic11.jpg" alt=""></a></li>
												<li><a href="images/t-pic12.jpg"><img src="images/pic12.jpg" alt=""></a></li>
												<li><a href="images/t-pic13.jpg"><img src="images/pic13.jpg" alt=""></a></li>
												<li><a href="images/t-pic14.jpg"><img src="images/pic14.jpg" alt=""></a></li>
												<li><a href="images/t-pic15.jpg"><img src="images/pic15.jpg" alt=""></a></li>
												<li><a href="images/t-pic16.jpg"><img src="images/pic16.jpg" alt=""></a></li>
												
                                                                                    </marquee>
											<div class="clear"> </div>
										</ul><br>
										
								</div>
								<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>

									<script type="text/javascript" src="js/jquery.lightbox.js"></script>
								    <link rel="stylesheet" type="text/css" href="css/lightbox.css" media="screen">
								  <script type="text/javascript">
								    $(function() {
								        $('.gallery a').lightBox();
								    });
								    </script>
							</div>
							<div class="bottom-grid1 bottom-last">
									<h3>Find More</h3>
									
                                                                       <div class="widget_wrap" style="width:520px;height:504px;"><iframe src="https://www.zomato.com/widgets/all_collections.php?city_id=1&language_id=1&theme=red&widgetType=large" style="position:relative;width:100%;height:100%;" border="0" frameborder="0"></iframe></div>
								</div>
								<div class="clear"> </div>
							</div>
							<div class="clear"> </div>
			</div>
	</div>
<div class="footer-bottom">
 	<div class="wrap">
 		<div class="copy">
			<p> © 2016 All rights Reserved | Open Source Project by Ahmar Abdullah, Anam Najeeb, Arisha Zaidi. </a></p>
		</div>
 	</div>
 </div>
</body>
</html>

    	
    	
            