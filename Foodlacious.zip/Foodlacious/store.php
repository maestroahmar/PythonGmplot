<?php
$link = mysqli_connect("localhost", "root", "", "restaurant");

/* check connection */
if (mysqli_connect_errno()) {
    printf("Connect failed: %s\n", mysqli_connect_error());
    exit();
}
$fname = filter_input(INPUT_POST, "fname");
$email = filter_input(INPUT_POST, "email");
echo "$email";

$query = "INSERT INTO neworders VALUES ('$fname', '$email')";
mysqli_query($link, $query);

printf ("New Record has id %d.\n", mysqli_insert_id($link));



/* close connection */
mysqli_close($link);
?>