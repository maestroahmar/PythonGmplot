
<!--A Design by W3layouts
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<head>
<title>Foodlacious - Contact</title>
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
<link href='http://fonts.googleapis.com/css?family=Merriweather+Sans' rel='stylesheet' type='text/css'>
<meta name="viewport" content="initial-scale=1.0, user-scalable=no" />
 <meta name="viewport" content="initial-scale=1.0, user-scalable=no" />
    <meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
    
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDh6R3M9ZETk_qYQsZM2UXIdwHTIWkLHLQ"
            type="text/javascript"></script>
    <script type="text/javascript">
        <?php
if($_GET){
 
    // get latitude, longitude and formatted address
    $data_arr = geocode($_GET['loc']);
 
    // if able to geocode the address
    if($data_arr){
         
        $latitude = $data_arr[0];
        $longitude = $data_arr[1];
        $formatted_address = $data_arr[2];
                     
    ?>
 
    <!-- google map will be shown here -->
    <div id="gmap_canvas">Loading map...</div>
    <div id='map-label'>Map shows approximate location.</div>
 
    <!-- JavaScript to show google map -->
    <script type="text/javascript" src="http://maps.google.com/maps/api/js"></script>    
    <script type="text/javascript">
        function init_map() {
            var myOptions = {
                zoom: 14,
                center: new google.maps.LatLng(<?php echo $latitude; ?>, <?php echo $longitude; ?>),
                mapTypeId: google.maps.MapTypeId.ROADMAP
            };
            map = new google.maps.Map(document.getElementById("gmap_canvas"), myOptions);
            marker = new google.maps.Marker({
                map: map,
                position: new google.maps.LatLng(<?php echo $latitude; ?>, <?php echo $longitude; ?>)
            });
            infowindow = new google.maps.InfoWindow({
                content: "<?php echo $formatted_address; ?>"
            });
            google.maps.event.addListener(marker, "click", function () {
                infowindow.open(map, marker);
            });
            infowindow.open(map, marker);
        }
        google.maps.event.addDomListener(window, 'load', init_map);
   
 
    <?php
 
    // if unable to geocode the address
    }else{
        echo "No map found.";
    }
}
?>
        


            function initMap() {
        var map = new google.maps.Map(document.getElementById('map'), {
          center: {lat: 26.863905 , lng: 80.902799},
          zoom: 10
        });
        var infoWindow = new google.maps.InfoWindow({map: map});

        // Try HTML5 geolocation.
        if (navigator.geolocation) {
          navigator.geolocation.getCurrentPosition(function(position) {
            var pos = {
              lat: position.coords.latitude,
              lng: position.coords.longitude
            };

            infoWindow.setPosition(pos);
            infoWindow.setContent('Location found.');
            map.setCenter(pos);
          }, function() {
            handleLocationError(true, infoWindow, map.getCenter());
          });
        } else {
          // Browser doesn't support Geolocation
          handleLocationError(false, infoWindow, map.getCenter());
        }
      }

      function handleLocationError(browserHasGeolocation, infoWindow, pos) {
        infoWindow.setPosition(pos);
        infoWindow.setContent(browserHasGeolocation ?
                              'Error: The Geolocation service failed.' :
                              'Error: Your browser doesn\'t support geolocation.');
      }

    var customIcons = {
      restaurant: {
        icon: 'http://labs.google.com/ridefinder/images/mm_20_blue.png'
      },
      bar: {
        icon: 'http://labs.google.com/ridefinder/images/mm_20_red.png'
      }
    };

    function load() {
      var map = new google.maps.Map(document.getElementById("map"), {
        center: new google.maps.LatLng(26.856447 ,80.945655 ),
        zoom: 13,
        mapTypeId: 'roadmap'
      });
      var infoWindow = new google.maps.InfoWindow;

      // Change this depending on the name of your PHP file
      downloadUrl("maps.php", function(data) {
        var xml = data.responseXML;
        var markers = xml.documentElement.getElementsByTagName("marker");
        for (var i = 0; i < markers.length; i++) {
          var name = markers[i].getAttribute("name");
          var address = markers[i].getAttribute("address");
          var type = markers[i].getAttribute("type");
          var point = new google.maps.LatLng(
              parseFloat(markers[i].getAttribute("lat")),
              parseFloat(markers[i].getAttribute("lng")));
          var html = "<b>" + name + "</b> <br/>" + address;
          var icon = customIcons[type] || {};
          var marker = new google.maps.Marker({
            map: map,
            position: point,
            icon: icon.icon
          });
          bindInfoWindow(marker, map, infoWindow, html);
        }
      });
    }

    function bindInfoWindow(marker, map, infoWindow, html) {
      google.maps.event.addListener(marker, 'click', function() {
        infoWindow.setContent(html);
        infoWindow.open(map, marker);
      });
    }

    function downloadUrl(url, callback) {
      var request = window.ActiveXObject ?
          new ActiveXObject('Microsoft.XMLHTTP') :
          new XMLHttpRequest;

      request.onreadystatechange = function() {
        if (request.readyState == 4) {
          request.onreadystatechange = doNothing;
          callback(request, request.status);
        }
      };

      request.open('GET', url, true);
      request.send(null);
    }

    function doNothing() {}

    //]]>

  </script>
  <?php
  function getDistance($addressFrom, $addressTo, $unit){
    //Change address format
    $formattedAddrFrom = str_replace(' ','+',$addressFrom);
    $formattedAddrTo = str_replace(' ','+',$addressTo);
    
    //Send request and receive json data
    $geocodeFrom = file_get_contents('http://maps.google.com/maps/api/geocode/json?address='.$formattedAddrFrom.'&sensor=false&key=AIzaSyDh6R3M9ZETk_qYQsZM2UXIdwHTIWkLHLQ');
    $outputFrom = json_decode($geocodeFrom);
    $geocodeTo = file_get_contents('http://maps.google.com/maps/api/geocode/json?address='.$formattedAddrTo.'&sensor=false&key=AIzaSyDh6R3M9ZETk_qYQsZM2UXIdwHTIWkLHLQ');
    $outputTo = json_decode($geocodeTo);
    
    //Get latitude and longitude from geo data
    $latitudeFrom = $outputFrom->results[0]->geometry->location->lat;
    $longitudeFrom = $outputFrom->results[0]->geometry->location->lng;
    $latitudeTo = $outputTo->results[0]->geometry->location->lat;
    $longitudeTo = $outputTo->results[0]->geometry->location->lng;
    
    //Calculate distance from latitude and longitude
    $theta = $longitudeFrom - $longitudeTo;
    $dist = sin(deg2rad($latitudeFrom)) * sin(deg2rad($latitudeTo)) +  cos(deg2rad($latitudeFrom)) * cos(deg2rad($latitudeTo)) * cos(deg2rad($theta));
    $dist = acos($dist);
    $dist = rad2deg($dist);
    $miles = $dist * 60 * 1.1515;
    $unit = strtoupper($unit);
    if ($unit == "K") {
        return ($miles * 1.609344).' km';
    } else if ($unit == "N") {
        return ($miles * 0.8684).' nm';
    } else {
        return $miles.' mi';
    }
}
  ?>
</head>
<body onload="load()">
    
<div class="header-box"></div>
<div class="wrap"> 
	<div class="total">
		<div class="header">
			<div class="header-bot">
				<div class="logo">
					<a href="index.html"><img src="images/restaurant logo.png" alt=""/></a>
				</div>
				<ul class="follow_icon">
					<li><a href="#"><img src="images/fb1.png" alt=""></a></li>
					<li><a href="#"><img src="images/rss.png" alt=""></a></li>
					<li><a href="#"><img src="images/tw.png" alt=""></a></li>
					<li><a href="#"><img src="images/g+.png" alt=""></a></li>
                                        <li><div class="g-signin2" data-onsuccess="onSignIn" data-theme="dark"></div> 
    <script>
      function onSignIn(googleUser) {
        // Useful data for your client-side scripts:
        var profile = googleUser.getBasicProfile();
        console.log("ID: " + profile.getId());
        // Don't send this directly to your server!
        console.log('Full Name: ' + profile.getName());
         name = profile.getName();
         
         document.getElementById("dispname").innerHTML = name;
        
        console.log('Given Name: ' + profile.getGivenName());
         pname = profile.getGivenName();
        console.log('Family Name: ' + profile.getFamilyName());
                 fname = profile.getFamilyName();
        console.log("Image URL: " + profile.getImageUrl());
         img = profile.getImageUrl();
         document.getElementById("prof").innerHTML = img;
         
        console.log("Email: " + profile.getEmail());
         mail = profile.getEmail();
         document.getElementById("email").innerHTML = mail;
         
      

        // The ID token you need to pass to your backend:
        var id_token = googleUser.getAuthResponse().id_token;
        console.log("ID Token: " + id_token);
      };
      
      
      
    </script> </li> </ul>
                            <script type="text/javascript">
                                function sendmail()
                                {
                                var result = "<?php callme(); ?>";
                                alert(result);
                                return false;
 
                                }</script>
                        </div>
			
			    
			<div class="search-bar">
			    <input type="text" class="textbox" value=" Search" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Search';}">
			    <input name="searchsubmit" type="image" src="images/search-icon.png" value="Go" id="searchsubmit" class="btn">
         	     <div class="clear"></div>
    		</div>
			<div class="clear"></div> 
		 </div>	
		<div class="menu"> 	
			<div class="top-nav">
				<ul>
                                    <li><a href="index.php">Home</a></li>
					<li><a href="about.html">About</a></li> 
					<li><a href="menu.html">Menu</a></li> 
					<li><a href="services.html">Services</a></li> 
					<li class="active"><a href="">Contact</a></li>
				</ul>
			</div>
		</div>		
		<div class="banner">
		</div>
   </div>
<div class="main">
	  <div class="section group">
				<div class="col span_2_of_contact">
				  <div class="contact-form">
				  	<h3>Order Online</h3>
                                        <form method="post" action="contact.php">
					    	<div>
						    	<span><label>Name</label></span>
						    	<span><input name="name" id="name" type="text" class="textbox"></span>
						    </div>
						    <div>
						    	<span><label>E-Mail</label></span>
                                                        <span><input name="email" id="email" type="text" class="textbox"></span>
						    </div>
						    <div>
						     	<span><label>Mobile</label></span>
                                                        <span><input name="mobile" id="mobile" type="text" class="textbox"></span>
						    </div>
						   
						   <div>
                                                       <span><input type="submit" onclick="sendmail();" value="Submit"></span>
						  </div>
					    </form>
				  </div>
  				</div>
                                <?php 
                          function callme()
                          {
                              if (isset($_POST["name"])){
                              $name = filter_input(INPUT_POST, "name");

                               }  
                               if (isset($_POST["email"])){
                              $email = filter_input(INPUT_POST, "email");
                               }  
                                if (isset($_POST["mobile"])){
                              $mobile = filter_input(INPUT_POST, "mobile");
                               } 
                  $msg = "Thanks $name!  For checking out this website";


                  $msg = wordwrap($msg,70);

                  $headers = "From: ahmarjohndj@gmail.com" . "\r\n" .

                  mail($email,"Thanks",$msg,$headers);
                          }
                  ?>
        
				<div class="col span_1_of_contact">
					<div class="contact_info">
    	 				<h3>Where are you now?</h3>
                                        
                                        <div style="position:relative;" >
                                            <form action="contact.php" method="get">
                                                <input type="text" id="loc" name="loc">
                                            <input type="submit" id="butt" title="Find">
                                            </form> <br>
                                            <div id="map" style="width: 400px; height: 400px"> </div>
                                            
                                        </div>
                                      
							   	
					    	  
      				</div>
      			<div class="company_address">
				     	<h3>Address</h3>
						    	<p>500 Lorem Ipsum Dolor Sit,</p>
						   		<p>22-56-2-9 Sit Amet, Lorem,</p>
						   	
				   		<p>Phone:(00) 222 666 444</p>
				   		<p>Fax: (000) 000 00 00 0</p>
				 	 	<p>Email: <span>info[at]mycompany.com</span></p>
				   		<p>Follow on: <span>Facebook</span>, <span>Twitter</span></p>
                                                
				   </div>
				 </div>
				 <div class="clear"></div> 
			  </div>
		   		<div class="heading">
				  	<h3>Our Staff</h3>
				</div>
		   		<div class="about-bottom">
				<div class="col_1_of_4 span_1_of_4">
					<img src="images/pic17.jpg" alt=""/>
						<div class="item_content">
 							<h6 class="item_title">
							<span class="item_title_part0">John McCois </span></h6>
							<div class="item_text"><p>lorem ipsum doloerut</p></div>
							<div class="item_text"><p>Ph No:800-000000</p></div>
							<span class="item_title_part0">Mail(at)superior.com </span>
						</div>
				</div>
				<div class="col_1_of_4 span_1_of_4">
					<img src="images/pic18.jpg" alt=""/>
						<div class="item_content">
 							<h6 class="item_title">
							<span class="item_title_part0">John McCois </span></h6>
							<div class="item_text"><p>lorem ipsum doloerut</p></div>
							<div class="item_text"><p>Ph No:800-000000</p></div>
							<span class="item_title_part0">Mail(at)superior.com </span>
						</div>
				</div>
				<div class="col_1_of_4 span_1_of_4">
					<img src="images/pic19.jpg" alt=""/>
						<div class="item_content">
 							<h6 class="item_title">
							<span class="item_title_part0">John McCois </span></h6>
							<div class="item_text"><p>lorem ipsum doloerut</p></div>
							<div class="item_text"><p>Ph No:800-000000</p></div>
							<span class="item_title_part0">Mail(at)superior.com </span>
						</div>
				</div>
				<div class="col_1_of_4 span_1_of_4">
					<img src="images/pic20.jpg" alt=""/>
						<div class="item_content">
 							<h6 class="item_title">
							<span class="item_title_part0">John McCois </span></h6>
							<div class="item_text"><p>lorem ipsum doloerut</p></div>
							<div class="item_text"><p>Ph No:800-000000</p></div>
							<span class="item_title_part0">Mail(at)superior.com </span>
						</div>
				</div>
				<div class="clear"></div> 		
			</div>
		     <div class="clear"> </div>
			</div>
	</div>
<div class="footer-bottom">
 	<div class="wrap">
 		<div class="copy">
			<p> © 2013 All rights Reserved | Design by <a href="http://w3layouts.com">W3Layouts</a></p>
		</div>
 	</div>
 </div>
</body>
</html>

    	
       