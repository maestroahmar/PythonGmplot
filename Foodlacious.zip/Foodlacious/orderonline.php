<html>
    <body>
        <script type="text/javascript">
 function processForm() { 
    $.ajax( {
        type: 'POST',
        url: 'orderonline.php',
        data: { checked_box : $('input:checkbox:checked').val()},

        success: function(data) {
            $('#message').html(data);
        }
    } );
}
</script>
        <input type="checkbox" name="standard_form[]" value="A" onclick="processForm()">
<input type="checkbox" name="premium_form[]" value="B" onclick="processForm()">
<?php
if(IsChecked('standard_form','A'))
    {
      $price += IsChecked('standard_form','A') ? 10 : 0;
    }
   return $price ; 
   ?>
    </body>
        
</html>