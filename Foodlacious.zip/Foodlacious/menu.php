
<!DOCTYPE HTML>
<html>
<head>
<title>Free uperior Website Template | Menu :: w3layouts</title>
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href='http://fonts.googleapis.com/css?family=Merriweather+Sans' rel='stylesheet' type='text/css'>
 <script>
    function add()
    {
     var xhttp = new XMLHttpRequest();
     
  xhttp.onreadystatechange = function() {
    if (xhttp.readyState === 4 && xhttp.status === 200) {
      document.postElementById("pay").innerHTML = tot;
    }
  };
     tot = 0;
     tot = tot + parseInt(document.postElementById("dish1").value.toString());
  xhttp.open("GET", "menu.php?t=" + Math.random()", true);
  xhttp.send();  
  
       
                

    }
    </script>

</head>
<body>
<div class="header-box"></div>
<div class="wrap"> 
	<div class="total">
		<div class="header">
			<div class="header-bot">
				<div class="logo">
					<a href="index.html"><img src="images/restaurant logo.png" alt=""/></a>
				</div>
				<ul class="follow_icon">
					<li><a href="#"><img src="images/fb1.png" alt=""></a></li>
					<li><a href="#"><img src="images/rss.png" alt=""></a></li>
					<li><a href="#"><img src="images/tw.png" alt=""></a></li>
					<li><a href="#"><img src="images/g+.png" alt=""></a></li>
				</ul>
			    <div class="clear"></div> 
			</div>
			<div class="search-bar">
                            <form action="menu.php" method="post">
                            
                               
                            

                            </form>
                            
                            
                            <div class="clear">
                                
                            </div>
    		</div>
			<div class="clear"></div> 
		 </div>	
		<div class="menu"> 	
			<div class="top-nav">
				<ul>
					<li><a href="index.php">Home</a></li>
                                        <li><a href="about.php">About</a></li> |
                                        <li class="active"><a href="menu.php">Menu</a></li> |
					<li><a href="services.php">Services</a></li> |
                                        <li><a href="contact.php">Contact</a></li>
				</ul>
			</div>
		</div>		
		<div class="banner">
		</div>
   </div>
     <div data-role="main" class="ui-content">

    <div data-role="popup" id="myPopup" class="ui-content" style="min-width:250px;">
<div class="main">
	  <div class="pricing">
				<div class="col_1_of_menu span_1_of_menu">
					<div class="inner-block">
                                    <form  method="post">        
             <h3 class="top-2">Shakes and Beverages</h3>
             <ul class="list-1 top-1 bot-2">
                
                 <li><input type="checkbox" name = "language[]" id="dish"  value ="100">Orange Shake <span> 100.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish2" value ="100">Majestic Vanilla Shake <span> 100.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish3" value ="100">Strawberry Shake <span> 100.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish4" value ="100">Chocolate Shake <span> 100.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish5" value ="100">Pineapple Shake <span> 100.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish6" value ="100">Mango Shake <span> 100.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish7" value ="100">Butter Scotch Shake <span> 100.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish8" value ="100">Kesar Pista Shake <span> 105.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish9" value ="100">Milk Badam Shake <span> 100.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Litchi Shake <span> 100.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Fruit Punch Shake <span> 140.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Cold Coffee <span> 75.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Cold Coffee(With Ice Cream) <span> 90.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Hot Coffee <span> 50.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Tea <span> 30.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Espresso Coffee <span> 70.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Mineral Water <span> 50.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Jal Jeera <span> 40.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Cold Drink <span> 40.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Fresh Lime Soda(Sweet/Salted) <span> 60.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Punjabi Lassi(Sweet/Salt) <span> 100.00</span><strong>&nbsp;</strong></li>
                 <input type="submit" id="pay" name="pay" title="pay" >
              <?php  
 if(isset($_POST["pay"]))  
 {  
     $tot = 0;
      if(!empty($_POST["language"]))  
      {  
          $tot;
           echo '<h3>Total Bill</h3>';  
           foreach($_POST["language"] as $language)  
           {  
                 $tot = $tot + $language;
           }  
           echo "$tot";
      }  
      else  
      {  
           echo "Please Select Atleast one Dish to finish";  
      }  
 }  
 ?>  

             </ul>
             
             
             <h3>Soups</h3>
             <ul class="list-1 top-4">
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Tomato Soup <span> 60.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Lemon Coriander Soup <span> 65.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Peking Soup <span> 70.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Manchow soup <span> 75.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Noodle Soup <span> 60.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">French Onion Soup <span> 105.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Spinach Soup <span> 80.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Tom Yum soup <span> 105.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Chicken Peking Soup <span> 100.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Chicken Manchow Soup <span> 150.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Hot & Sour Soup(Veg.) <span> 75.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Hot & Sour Soup(Non Veg.) <span> 105.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Sweet Corn Soup(Veg) <span> 85.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Sweet Corn Soup(Non Veg) <span> 85.00</span><strong>&nbsp;</strong></li>
                 
            
             <input type="submit" id="pay" name="pay" title="pay" >
             </ul>
              <?php  
 if(isset($_POST["pay"]))  
 {  
     $tot = 0;
      if(!empty($_POST["language"]))  
      {  
          $tot;
           echo '<h3>Total Bill</h3>';  
           foreach($_POST["language"] as $language)  
           {  
                 $tot = $tot + $language;
           }  
           echo "$tot";
      }  
      else  
      {  
           echo "Please Select Atleast one Dish to finish";  
      }  
 } ?>  
             
             <h3 class="top-2">Pizzas</h3>
             <ul class="list-1 top-4">
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Veg Italian <span> 190.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Veggie Surprise Pizza <span> 200.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Paneer Tikka Chilly <span> 220.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Paneer Hot & Spicy <span> 210.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Mushroom Italian <span> 215.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Mushroom Capsicum Onion <span> 215.00</span><strong>&nbsp;</strong></li>
                <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Tomato Capsicum Onion <span> 180.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Cheese Capsicum Onion <span> 190.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Chicken Italian <span> 200.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Chicken Tikka Green Chilly <span> 210.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Chicken Hot & Spicy <span> 215.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Chicken Capsicum Onion <span> 210.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Chicken Prince <span> 220.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Chicken Mushroom <span> 230.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Non Veg Italian Spicy <span> 230.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Fish Dragon <span> 300.00</span><strong>&nbsp;</strong></li> 
           <input type="submit" id="pay" name="pay" title="pay" >
              <?php  
 if(isset($_POST["pay"]))  
 {  
     $tot = 0;
      if(!empty($_POST["language"]))  
      {  
          $tot;
           echo '<h3>Total Bill</h3>';  
           foreach($_POST["language"] as $language)  
           {  
                 $tot = $tot + $language;
           }  
           echo "$tot";
      }  
      else  
      {  
           echo "Please Select Atleast one Dish to finish";  
      }  
 } ?>  
             </ul>
             
             <h3 class="top-2">Noodles</h3>
             <ul class="list-1 top-1">
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Veg Singapore Noodles <span> 215.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Veg. Hakka Noodles <span> 210.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Veg Special Chowmein <span> 225.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Veg Hot Garlic Noodles <span> 230.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Veg Hong Kong Style Noodles <span> 220.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Cheese Chowmein <span> 225.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Mixed Chowmein(Non Veg) <span> 250.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Hot Garlic Noodles(Non Veg) <span> 250.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Schezwan Noodles(Non Veg) <span> 250.00</span><strong>&nbsp;</strong></li>
                  <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Chicken Hakka Noodles <span> 250.00</span><strong>&nbsp;</strong></li>
                  <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Chicken Chowmein <span> 230.00</span><strong>&nbsp;</strong></li>
                  <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Egg Chowmein <span> 220.00</span><strong>&nbsp;</strong></li>
             </ul>
            <input type="submit" id="pay" name="pay" title="pay" >
              <?php  
 if(isset($_POST["pay"]))  
 {  
     $tot = 0;
      if(!empty($_POST["language"]))  
      {  
          $tot;
           echo '<h3>Total Bill</h3>';  
           foreach($_POST["language"] as $language)  
           {  
                 $tot = $tot + $language;
           }  
           echo "$tot";
      }  
      else  
      {  
           echo "Please Select Atleast one Dish to finish";  
      }  
 } ?>  
             
             <h3 class="top-2">Chinese</h3>
             <ul class="list-1 top-1">
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Veg. Spring Roll <span> 190.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">American Corn Chilly <span> 200.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Veg 65(Dry) <span> 230.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Crispy Manchurian with Baby Corn <span> 260.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Veg Manchurian Dry <span> 230.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Chicken Lollipop <span> 320.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Chicken Chilly(Dry) <span> 300.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Spicy Double Mushroom <span> 240.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Mushroom Manchurian <span> 235.00</span><strong>&nbsp;</strong></li>
                  <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Mushroom Schezwan <span> 270.00</span><strong>&nbsp;</strong></li>
                  <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Paneer Manchurian <span> 235.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Veg Hot Garlic <span> 195.00</span><strong>&nbsp;</strong></li>
                  <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Veg Schezwan <span> 225.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Veg. Chow Chow <span> 225.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Chicken Hong Kong Style <span> 290.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Chicken Hot Garlic Sauce <span> 280.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Chicken with Baby Corn <span> 290.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Ginger Chicken <span> 280.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Garlic Chicken <span> 280.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Chicken Manchurian <span> 300.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Chilly Chicken <span> 280.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Chicken Schezwan <span> 290.00</span><strong>&nbsp;</strong></li>
                  <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Mutton Manchurian <span> 270.00</span><strong>&nbsp;</strong></li>
                  <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Ginger Mutton <span> 290.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Garlic Mutton <span> 290.00</span><strong>&nbsp;</strong></li>
                  <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Mutton Schezwan <span> 300.00</span><strong>&nbsp;</strong></li>
             </ul>
            <input type="submit" id="pay" name="pay" title="pay" >
              <?php  
 if(isset($_POST["pay"]))  
 {  
     $tot = 0;
      if(!empty($_POST["language"]))  
      {  
          $tot;
           echo '<h3>Total Bill</h3>';  
           foreach($_POST["language"] as $language)  
           {  
                 $tot = $tot + $language;
           }  
           echo "$tot";
      }  
      else  
      {  
           echo "Please Select Atleast one Dish to finish";  
      }  
 } ?>  
                                    </form>
           </div> 
				</div>
				<div class="col_1_of_menu span_1_of_menu">
					<div class="inner-block">
                                            <h3 class="top-2">Barbeque</h3>
                                            <form  method="post"> 
             <ul class="list-1 top-4">
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Paneer Tikka <span> 230.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Paneer Kastoori Tikka <span> 240.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Sholey Paneer Tikka(Spicy) <span> 250.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Vepostable Seekh Kabab <span> 150.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Vepostable Assorted Kabab <span> 375.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Murg Tangri Kabab <span> 340.00</span><strong>&nbsp;</strong></li>
                  <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Murg Reshmi Kabab <span> 310.00</span><strong>&nbsp;</strong></li>
                  <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Murg Tikka <span> 310.00</span><strong>&nbsp;</strong></li>
                  <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Murg Tandoori <span> 395.00</span><strong>&nbsp;</strong></li>
                  <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Murg Multani <span> 410.00</span><strong>&nbsp;</strong></li>
                  <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Murg Lehsunia Tikka <span> 330.00</span><strong>&nbsp;</strong></li>
                  <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Mutton Shami Kabab <span> 240.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Mutton Seekh Kabab <span> 260.00</span><strong>&nbsp;</strong></li>
                  <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Fish Tikka <span> 370.00</span><strong>&nbsp;</strong></li>
                  <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Fish Ajwaini Tikka <span> 380.00</span><strong>&nbsp;</strong></li>
             </ul>
                                               <input type="submit" id="pay" name="pay" title="pay" >
              <?php  
 if(isset($_POST["pay"]))  
 {  
     $tot = 0;
      if(!empty($_POST["language"]))  
      {  
          $tot;
           echo '<h3>Total Bill</h3>';  
           foreach($_POST["language"] as $language)  
           {  
                 $tot = $tot + $language;
           }  
           echo "$tot";
      }  
      else  
      {  
           echo "Please Select Atleast one Dish to finish";  
      }  
 } ?>  
                                            <h3 class="top-2">Continental</h3>
             <ul class="list-1 top-4">
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Cheese Paprica <span> 240.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Baked Mushrrom with Baby Corn <span> 290.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Mixed Veg Grilled <span> 240.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Macroni Butter fried <span> 200.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Grilled Mushroom with Smash Potato & Boiled Veg <span> 265.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Chicken Paprica <span> 240.00</span><strong>&nbsp;</strong></li>
                  <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Chicken Grilled with Boiled Veg <span> 250.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Baked Chicken <span> 290.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Chicken Roast <span> 260.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Chicken Mayonese <span> 260.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Mutton Grilled <span> 275.00</span><strong>&nbsp;</strong></li>
                  <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Mixed Non Veg Grilled <span> 305.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Grilled Fish <span> 340.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Fish Fried With Boiled Veg <span> 340.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Baked Fish <span> 340.00</span><strong>&nbsp;</strong></li>
             </ul>
                                           <input type="submit" id="pay" name="pay" title="pay" >
              <?php  
 if(isset($_POST["pay"]))  
 {  
     $tot = 0;
      if(!empty($_POST["language"]))  
      {  
          $tot;
           echo '<h3>Total Bill</h3>';  
           foreach($_POST["language"] as $language)  
           {  
                 $tot = $tot + $language;
           }  
           echo "$tot";
      }  
      else  
      {  
           echo "Please Select Atleast one Dish to finish";  
      }  
 } ?>  
             <h3 class="top-2">Fish</h3>
             <ul class="list-1 top-1">
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Fish Manchurian <span> 330.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Fish Hot Garlic Sauce <span> 330.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Fish Sweet and Sour <span> 330.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Fish Chilly <span> 330.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Royal Fish(Dry) <span> 310.00</span><strong>&nbsp;</strong></li>
                                  </ul>
            <input type="submit" id="pay" name="pay" title="pay" >
              <?php  
 if(isset($_POST["pay"]))  
 {  
     $tot = 0;
      if(!empty($_POST["language"]))  
      {  
          $tot;
           echo '<h3>Total Bill</h3>';  
           foreach($_POST["language"] as $language)  
           {  
                 $tot = $tot + $language;
           }  
           echo "$tot";
      }  
      else  
      {  
           echo "Please Select Atleast one Dish to finish";  
      }  
 } ?>  
             <h3 class="top-2">Rice</h3>
             <ul class="list-1 top-1">
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Veg Fried Rice <span> 210.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Cheese Fried Rice <span> 240.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Mixed Fried Rice <span> 245.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Chicken Fried Rice <span> 245.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Chicken Schezwan Fried Rice(Spicy) <span> 260.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Mutton Fried Rice <span> 260.00</span><strong>&nbsp;</strong></li>
             <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Egg Fried Rice <span> 220.00</span><strong>&nbsp;</strong></li>
             <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Veg Handi Dum Biryani <span> 210.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Kashmiri Pulao <span> 210.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Navratan Pulao <span> 205.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Cheese Pulao <span> 200.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Matar Pulao <span> 185.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Jeera Pulao <span> 180.00</span><strong>&nbsp;</strong></li>
             <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Murg Handi Dum Biryani <span> 270.00</span><strong>&nbsp;</strong></li>
             <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Mutton Handi Dum Biryani <span> 280.00</span><strong>&nbsp;</strong></li>
             <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Hydrabadi Handi Dum Biryani <span> 300.00</span><strong>&nbsp;</strong></li>
             <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Egg Handi Dum Biryani <span> 240.00</span><strong>&nbsp;</strong></li>
             </ul>
            <input type="submit" id="pay" name="pay" title="pay" >
              <?php  
 if(isset($_POST["pay"]))  
 {  
     $tot = 0;
      if(!empty($_POST["language"]))  
      {  
          $tot;
           echo '<h3>Total Bill</h3>';  
           foreach($_POST["language"] as $language)  
           {  
                 $tot = $tot + $language;
           }  
           echo "$tot";
      }  
      else  
      {  
           echo "Please Select Atleast one Dish to finish";  
      }  
 } ?>  
             <h3 class="top-2">Breads</h3>
             <ul class="list-1 top-1">
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Tawa Butter Roti <span> 45.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Tandoor Roti <span> 25.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Roomali Roti <span> 10.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Missi Roti <span> 60.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Laccha Paratha <span> 60.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Pudina Paratha <span> 70.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Plain Naan <span> 60.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Butter Naan <span> 75.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Plain Kulcha <span> 70.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Stuffed Kulcha <span> 90.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Paneer Stuffed Kulcha <span> 90.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Onion Stuffed Kulcha <span> 80.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Stuffed Naan <span> 85.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Khasta Roti <span> 80.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Cheese Garlic Naan <span> 100.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Bread Basket <span> 190.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Keema Naam(Mutton) <span> 135.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Keema Paratha(Mutton) <span> 130.00</span><strong>&nbsp;</strong></li>
             </ul> 
            <input type="submit" id="pay" name="pay" title="pay" >
              <?php  
 if(isset($_POST["pay"]))  
 {  
     $tot = 0;
      if(!empty($_POST["language"]))  
      {  
          $tot;
           echo '<h3>Total Bill</h3>';  
           foreach($_POST["language"] as $language)  
           {  
                 $tot = $tot + $language;
           }  
           echo "$tot";
      }  
      else  
      {  
           echo "Please Select Atleast one Dish to finish";  
      }  
 } ?>  
                                            </form>
             
           </div>
				</div>
				<div class="col_1_of_menu span_1_of_menu">
					<div class="inner-block">
             <h3 class="top-2">Indian(Veg)</h3>
             <ul class="list-1 top-1">
                 <form  method="post"> 
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Paneer Kaju Masala <span> 235.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Paneer Pasanda <span> 225.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Paneer Butter Masala <span> 245.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Paneer Kolhapuri <span> 230.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Palak Paneer <span> 220.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Handi Paneer <span> 225.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Cheese Kofta <span> 240.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Shahi Paneer <span> 225.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Malai Kofta <span> 230.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Kashmiri Dum Aaloo <span> 200.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Kadhai Veg <span> 230.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Veg Korma <span> 200.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Veg Keema Matar <span> 200.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Chana Masala <span> 180.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Mushroom Matar <span> 235.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Bahar-e-Mausam ki Sabzi <span> 180.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Dal Makhani <span> 200.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Dal Tadka <span> 190.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Lehar Paneer <span> 230.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Paneer Jhalfarezi <span> 225.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Veg Kolhapuri Kofta <span> 200.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Lacknawi Dum Aaloo <span> 200.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Mixed Veg <span> 200.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Veg Jaipuri <span> 210.00</span><strong>&nbsp;</strong></li>
             </ul>
             
             <h3>Indian(Non Veg)</h3>
             <ul class="list-1 top-4">
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Murg Dahiwala <span> 520.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Murg Kesari <span> 530.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Murg Kadhai <span> 520.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Murg Makhanwala(Butter Chicken) <span> 520.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Murg Kolhapuri <span> 520.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Murg Peshawari <span> 540.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Murg Afghani <span> 540.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Murg Mussalam <span> 570.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Murg Tikka Masala <span> 570.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Murg Lahori <span> 570.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Murg Do Pyaza <span> 220.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Murg Curry <span> 220.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Gosht Nargisi Kofta <span> 280.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Gosht Lababdar <span> 260.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Gosht Saagwala <span> 250.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Gosht Do Pyaza <span> 250.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Gosht Kadhai <span> 260.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Gosht Mughlai <span> 260.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Gosht Korma <span> 300.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Gosht Keema Hara Matar <span> 250.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Fish Curry <span> 330.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Fish Masala <span> 330.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Fish Lahori <span> 340.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Fish Tawa Masala <span> 345.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Egg Curry <span> 190.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Egg Bhujia <span> 170.00</span><strong>&nbsp;</strong></li>
                  </ul> 
             
             <h3>Side Orders</h3>
             <ul class="list-1 top-4">
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Chatpata Salad <span> 80.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Fresh Garden Salad <span> 80.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Onion Salad <span> 60.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Boondi Raita <span> 100.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Mixed Raita <span> 100.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Pineapple Raita <span> 130.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Kheera Raita <span> 100.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Fruit Raita <span> 120.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Pudina Raita <span> 100.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Aaloo Raita <span> 100.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Plain Curd <span> 90.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Fried Papad <span> 35.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Roasted Papad <span> 30.00</span><strong>&nbsp;</strong></li>
                 
                 </ul>
             
             <h3>Fast Food</h3>
             <ul class="list-1 top-4">
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Veg Burger <span> 105.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Cheese Burger <span> 120.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Veg Pakora <span> 115.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Cheese Pakora <span> 140.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Veg Cutlet <span> 115.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Cheese Cutlet <span> 125.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Pao Bhaji <span> 125.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Finger Chips <span> 120.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Veg Grilled Sandwich <span> 125.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Cheese Grilled Sandwich <span> 135.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Veg Club Sandwich <span> 155.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Veg Sandwich Plain <span> 115.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Chicken Burger <span> 125.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Mutton Burger <span> 130.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Chicken Cutlet <span> 150.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Mutton Cutlet <span> 150.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Fish Finger with French Fries <span> 320.00</span><strong>&nbsp;</strong></li>
                  <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Chicken Sandwich <span> 140.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Non Veg Club Sandwich <span> 190.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Chicken Grilled Sandwich <span> 150.00</span><strong>&nbsp;</strong></li>
             </ul> 
             <h3>Ice Cream</h3>
             <ul class="list-1 top-4">
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Vanilla Ice Cream <span> 75.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Ripe Strawberry Ice Cream <span> 75.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Banana Split <span> 150.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Moon Magic <span> 150.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Happiness Marine <span> 50.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Chocolate Chips <span> 85.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Casatta Slice <span> 95.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Butter Scotch <span> 85.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Real Kesar Pista <span> 90.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Fresh Strawberry <span> 90.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Handi Khas Kulfi <span> 85.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Pine Apple Delight <span> 85.00</span><strong>&nbsp;</strong></li>
                 <li><input type="checkbox" name = "language[]"id = "dish" value ="100">Tuti Fruity <span> 95.00</span><strong>&nbsp;</strong></li>
                                  </ul> 
          
                                        </div> 
				</div>
          </div> </div> </div> </div> </div>
              
				<div class="clear"></div> 
			</div>
		   		<div class="heading">
				  	<h3>Our Staff</h3>
				</div>
		   		<div class="about-bottom">
				<div class="col_1_of_4 span_1_of_4">
					<img src="images/pic17.jpg" alt=""/>
						<div class="item_content">
 							<h6 class="item_title">
							<class="item_title_part0">Anam Najeeb</span></h6>
							<div class="item_text"><p>lorem ipsum doloerut</p></div>
							<div class="item_text"><p>Ph No:800-000000</p></div>
							<class="item_title_part0">anamnaje@iul.ac.in</span>
						</div>
				</div>
				<div class="col_1_of_4 span_1_of_4">
					<img src="images/pic18.jpg" alt=""/>
						<div class="item_content">
 							<h6 class="item_title">
							<class="item_title_part0">John McCois</span></h6>
							<div class="item_text"><p>lorem ipsum doloerut</p></div>
							<div class="item_text"><p>Ph No:800-000000</p></div>
							<class="item_title_part0">Mail(at)superior.com </span>
						</div>
				</div>
				<div class="col_1_of_4 span_1_of_4">
					<img src="images/pic19.jpg" alt=""/>
						<div class="item_content">
 							<h6 class="item_title">
							<class="item_title_part0">Aleesha Zaidi</span></h6>
							<div class="item_text"><p>lorem ipsum doloerut</p></div>
							<div class="item_text"><p>Ph No:800-000000</p></div>
							<class="item_title_part0">aleeshazaidi@iul.ac.in</span>
						</div>
				</div>
				<div class="col_1_of_4 span_1_of_4">
					<img src="images/pic20.jpg" alt=""/>
						<div class="item_content">
 							<h6 class="item_title">
							<class="item_title_part0">Arisha Zaidi</span></h6>
							<div class="item_text"><p>lorem ipsum doloerut</p></div>
							<div class="item_text"><p>Ph No:800-000000</p></div>
							<class="item_title_part0">arishaza@iul.ac.in</span>
						</div>
				</div>
				<div class="clear"></div> 		
			</div>
		     <div class="clear"> </div>
			</div>
	</div>
<div class="footer-bottom">
 	<div class="wrap">
 		<div class="copy">
			<p> © 2016 All rights Reserved | Design by <a href="http://w3layouts.com">FOODLACIOUS</a></p>
		</div>
 	</div>
 </div>
</body>
</html>

    	
    	
            